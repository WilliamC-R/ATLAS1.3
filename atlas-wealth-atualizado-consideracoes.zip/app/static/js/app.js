const form = document.getElementById('plan-form');
const summaryCards = document.getElementById('summary-cards');
const comparisonTable = document.getElementById('comparison-table');
const timeline = document.getElementById('timeline');
const actionPlan = document.getElementById('action-plan');
const pdfLink = document.getElementById('pdf-link');
const assumptionsBox = document.getElementById('assumptions-box');
const portfolioOverview = document.getElementById('portfolio-overview');
const scenarioChart = document.getElementById('scenario-chart');
const scenarioHighlights = document.getElementById('scenario-highlights');
const gotoPlan = document.getElementById('goto-plan');

const tabButtons = [...document.querySelectorAll('.tab-button')];
const tabPanels = [...document.querySelectorAll('.tab-content')];

function setActiveTab(tabName) {
  tabButtons.forEach((button) => button.classList.toggle('active', button.dataset.tab === tabName));
  tabPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.tabPanel === tabName));
}

tabButtons.forEach((button) => {
  button.addEventListener('click', () => setActiveTab(button.dataset.tab));
});

gotoPlan.addEventListener('click', () => setActiveTab('plano'));

function parseLines(value, type) {
  return value
    .split('
')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split('|').map((item) => item.trim());
      if (type === 'goal') {
        return { name: parts[0], target_amount: Number(parts[1] || 0), target_year: Number(parts[2] || new Date().getFullYear()) };
      }
      return {
        year: Number(parts[0] || new Date().getFullYear()),
        title: parts[1] || 'Evento',
        impact_amount: Number(parts[2] || 0),
        recurring: (parts[3] || 'nao').toLowerCase() === 'sim',
      };
    });
}

function money(value) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
}

function pct(value) {
  return `${((value || 0) * 100).toFixed(1)}%`;
}

function collectPayload() {
  const data = new FormData(form);
  return {
    client_name: data.get('client_name'),
    age: Number(data.get('age')),
    dependents: Number(data.get('dependents')),
    monthly_income: Number(data.get('monthly_income')),
    monthly_expenses: Number(data.get('monthly_expenses')),
    monthly_contribution: Number(data.get('monthly_contribution')),
    invested_assets: Number(data.get('invested_assets')),
    real_estate_assets: Number(data.get('real_estate_assets')),
    cash_reserves: Number(data.get('cash_reserves')),
    company_equity: Number(data.get('company_equity')),
    target_age: Number(data.get('target_age')),
    desired_monthly_income_future: Number(data.get('desired_monthly_income_future')),
    tax_regime: data.get('tax_regime'),
    has_life_insurance: data.get('has_life_insurance'),
    has_emergency_reserve: data.get('has_emergency_reserve'),
    goals: parseLines(data.get('goals'), 'goal'),
    life_events: parseLines(data.get('life_events'), 'event'),
    comparison: {
      property_value: Number(data.get('property_value')),
      property_expected_sale_value: Number(data.get('property_expected_sale_value')),
      property_monthly_rent: Number(data.get('property_monthly_rent')),
      property_monthly_costs: Number(data.get('property_monthly_costs')),
      auction_discount_rate: Number(data.get('auction_discount_rate')),
      investment_initial: Number(data.get('investment_initial')),
      investment_monthly: Number(data.get('investment_monthly')),
      investment_years: Number(data.get('investment_years')),
      long_term_rate: Number(data.get('long_term_rate')),
      business_expected_roi: Number(data.get('business_expected_roi')),
    },
    advisor_notes: data.get('advisor_notes'),
  };
}

function renderAssumptions() {
  assumptionsBox.innerHTML = `
    <div class="note-grid">
      <article class="note-card"><strong>Selic estrutural</strong><p>5,5% ao ano como referência de longo prazo.</p></article>
      <article class="note-card"><strong>Banda de oscilação</strong><p>Até +2,0 p.p. e -1,0 p.p. nas projeções.</p></article>
      <article class="note-card"><strong>Pilar do plano</strong><p>Segurança de vida é tratada como base do wealth planning, com foco em liquidez sucessória e proteção familiar.</p></article>
    </div>
  `;
}

function renderScenarioChart(scenarioProjection) {
  const labels = scenarioProjection.annual_labels;
  const series = scenarioProjection.series;
  const palette = {
    Conservador: '#84cc16',
    Moderado: '#f59e0b',
    Sofisticado: '#2563eb',
  };
  const width = 1080;
  const height = 400;
  const margin = { top: 24, right: 36, bottom: 52, left: 72 };
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;

  const values = Object.values(series).flat();
  const min = Math.min(...values) * 0.94;
  const max = Math.max(...values) * 1.04;
  const xFor = (index) => margin.left + (plotWidth * index) / (labels.length - 1);
  const yFor = (value) => margin.top + plotHeight - ((value - min) / (max - min || 1)) * plotHeight;

  const gridLines = Array.from({ length: 5 }).map((_, idx) => {
    const y = margin.top + (plotHeight * idx) / 4;
    const value = max - ((max - min) * idx) / 4;
    return `
      <line class="grid-line" x1="${margin.left}" x2="${width - margin.right}" y1="${y}" y2="${y}" />
      <text class="axis-label" x="12" y="${y + 4}">${money(value)}</text>
    `;
  }).join('');

  const xLabels = labels.map((label, idx) => {
    if (idx !== 0 && idx !== 10 && idx !== 20) return '';
    return `<text class="axis-label" x="${xFor(idx)}" y="${height - 16}" text-anchor="middle">${label}</text>`;
  }).join('');

  const lines = Object.entries(series).map(([name, points]) => {
    const polyline = points.map((point, idx) => `${xFor(idx)},${yFor(point)}`).join(' ');
    const peak = points.reduce((best, value, idx) => value > best.value ? { value, idx } : best, { value: -Infinity, idx: 0 });
    const trough = points.reduce((best, value, idx) => value < best.value ? { value, idx } : best, { value: Infinity, idx: 0 });
    const endValue = points[points.length - 1];
    return `
      <polyline fill="none" stroke="${palette[name]}" stroke-width="3" points="${polyline}" />
      <circle cx="${xFor(peak.idx)}" cy="${yFor(peak.value)}" r="4" fill="${palette[name]}" />
      <circle cx="${xFor(trough.idx)}" cy="${yFor(trough.value)}" r="4" fill="${palette[name]}" />
      <text class="point-label" x="${xFor(points.length - 1) - 6}" y="${yFor(endValue) - 10}" text-anchor="end">${name}: ${money(endValue)}</text>
    `;
  }).join('');

  scenarioChart.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Gráfico de linhas dos três cenários">
      ${gridLines}
      <line class="grid-line" x1="${margin.left}" x2="${margin.left}" y1="${margin.top}" y2="${height - margin.bottom}" />
      <line class="grid-line" x1="${margin.left}" x2="${width - margin.right}" y1="${height - margin.bottom}" y2="${height - margin.bottom}" />
      ${lines}
      ${xLabels}
    </svg>
  `;
}

function renderPortfolioOverview(cards) {
  portfolioOverview.innerHTML = cards.map((card) => {
    const cssName = card.name.toLowerCase();
    return `
      <article class="portfolio-card">
        <h3>${card.name}</h3>
        <span class="level-badge level-${cssName}">${card.level}</span>
        <div class="allocation-columns">
          <div class="alloc-box"><span>Caixa</span><strong>${pct(card.allocation['Caixa'])}</strong></div>
          <div class="alloc-box"><span>Renda Fixa</span><strong>${pct(card.allocation['Renda Fixa'])}</strong></div>
          <div class="alloc-box"><span>Renda Variável</span><strong>${pct(card.allocation['Renda Variável'])}</strong></div>
        </div>
        <div class="allocation-columns">
          <div class="alloc-box"><span>10 anos</span><strong>${money(card.value_10y)}</strong></div>
          <div class="alloc-box"><span>20 anos</span><strong>${money(card.value_20y)}</strong></div>
          <div class="alloc-box"><span>Volatilidade</span><strong>${pct(card.volatility)}</strong></div>
        </div>
        <table class="asset-breakdown">
          <thead>
            <tr><th>Estratégia</th><th>Peso</th><th>Bucket</th></tr>
          </thead>
          <tbody>
            ${card.assets.map((asset) => `
              <tr>
                <td>${asset.name}</td>
                <td>${pct(asset.weight)}</td>
                <td>${asset.bucket}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </article>
    `;
  }).join('');
}

function renderResult(result) {
  const summary = result.summary;
  summaryCards.innerHTML = [
    ['Patrimônio atual', money(summary.current_net_worth)],
    ['Patrimônio projetado', money(summary.future_value)],
    ['Capital alvo', money(summary.retirement_target_capital)],
    ['Gap de capital', money(summary.capital_gap)],
    ['Reserva ideal', money(summary.emergency_reserve_target)],
    ['Segurança de vida', money(summary.life_security_capital)],
    ['Custo sucessório 20%', money(summary.succession_cost_estimate)],
    ['Proteção total sugerida', money(summary.protection_capital_needed)],
  ].map(([label, value]) => `<article class="metric"><span>${label}</span><strong>${value}</strong></article>`).join('');

  const comparisonLabels = {
    buy_property_future_value: 'Comprar imóvel',
    rent_and_invest_future_value: 'Alugar e investir',
    auction_property_future_value: 'Leilão',
    invest_in_business_future_value: 'Aportar na empresa',
    long_term_investment_future_value: 'Investimento de longo prazo',
  };

  comparisonTable.innerHTML = `<div class="table">${Object.entries(result.comparison)
    .filter(([key]) => key !== 'best_scenario')
    .map(([key, value]) => `<div class="table-row"><span>${comparisonLabels[key]}</span><strong>${money(value)}</strong></div>`)
    .join('')}
    <div class="table-row"><span>Melhor cenário</span><strong>${result.comparison.best_scenario.replaceAll('_', ' ')}</strong></div>
  </div>`;

  timeline.innerHTML = result.timeline
    .map((item) => `<div class="timeline-item"><strong>${item.year} — ${item.title}</strong><p>${item.detail}</p></div>`)
    .join('');

  actionPlan.innerHTML = result.action_plan.map((item) => `<li>${item}</li>`).join('');

  renderAssumptions();
  renderPortfolioOverview(result.scenario_projection.portfolio_cards);
  renderScenarioChart(result.scenario_projection);
  scenarioHighlights.innerHTML = result.scenario_projection.highlights.map((item) => `<li>${item}</li>`).join('');

  pdfLink.href = `/api/plans/${result.id}/pdf`;
  pdfLink.classList.remove('hidden');
  gotoPlan.classList.remove('hidden');
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  button.textContent = 'Gerando...';

  try {
    const response = await fetch('/api/plans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(collectPayload()),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Falha ao gerar o planejamento.');
    }

    const result = await response.json();
    renderResult(result);
    setActiveTab('plano');
  } catch (error) {
    alert(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Gerar planejamento';
  }
});
